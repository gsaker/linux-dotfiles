#!/usr/bin/env bash

rofi -opacity "50" -no-config -no-lazy-grab -show drun -modi drun -theme "$HOME/.config/polybar/menu"/launcher.rasi

